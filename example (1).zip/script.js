document.getElementById('change-text-button').addEventListener('click', function() {
    document.getElementById('text').textContent = 'You clicked the button!';
});
